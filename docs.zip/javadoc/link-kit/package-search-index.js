var packageSearchIndex = [{"l":"com.getmoneytree.linkkit","url":"com/getmoneytree/linkkit/package-summary.html"}, {"l":"All packages","url":"index.html"}]
