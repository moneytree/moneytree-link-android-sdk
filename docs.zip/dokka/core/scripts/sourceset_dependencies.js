sourceset_dependencies = '{":core:dokkaHtml/androidTestRelease": [], ":core:dokkaHtml/debug": [], ":core:dokkaHtml/main": [], ":core:dokkaHtml/release": []}'
